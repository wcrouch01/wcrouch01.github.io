# Personal Website

Website: http://www.jahancherian.com

This is my public personal website. It currently contains mostly updated information about my current escapades and experience, my notes from my time at UCLA and my work in both my personal and professional time ranging in both
development and design.

![Current Look] (./website_look.png)

There is yet to be a blog added, but that should be happening sometime soon so stay tuned.
